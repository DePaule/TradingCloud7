import os
import zipfile
import base64
import pyperclip

def is_binary_file(filepath, blocksize=1024):
    """
    Versucht zu ermitteln, ob eine Datei binär ist.
    Liest dazu einen Block der Datei und prüft, ob NUL-Bytes vorkommen.
    """
    try:
        with open(filepath, 'rb') as file:
            block = file.read(blocksize)
            # Enthält der Block NUL-Bytes, wird die Datei als binär betrachtet.
            if b'\0' in block:
                return True
    except Exception as e:
        print(f"Fehler beim Lesen von {filepath}: {e}")
        return True  # Bei Fehler lieber als binär einstufen
    return False

def zip_non_binary_files(root_dir, zip_path):
    """
    Durchläuft rekursiv den root_dir und fügt alle nicht-binären Dateien (außer im Ordner 'venv')
    in eine ZIP-Datei ein. Die originale Ordnerstruktur bleibt erhalten.
    """
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for folder, subfolders, files in os.walk(root_dir):
            # Überspringe den venv-Ordner
            if 'venv' in folder.split(os.sep):
                continue
            for file in files:
                filepath = os.path.join(folder, file)
                # Überspringe binäre Dateien
                if is_binary_file(filepath):
                    continue
                # Berechne den relativen Pfad, damit die Ordnerstruktur im Zip erhalten bleibt
                rel_path = os.path.relpath(filepath, root_dir)
                zipf.write(filepath, arcname=rel_path)
    print(f"ZIP-Datei wurde erstellt: {zip_path}")

def load_zip_to_clipboard(zip_path):
    """
    Liest die ZIP-Datei ein, kodiert sie base64 (als Text) und kopiert den Inhalt in den
    Zwischenspeicher, sodass du ihn z. B. in den Chat einfügen kannst.
    """
    with open(zip_path, "rb") as f:
        data = f.read()
    encoded_data = base64.b64encode(data).decode("utf-8")
    pyperclip.copy(encoded_data)
    print("Der Base64-kodierte Inhalt der ZIP-Datei wurde in den Zwischenspeicher geladen.")

def main():
    # Aktuellen Arbeitsordner als root_dir nutzen
    root_dir = os.getcwd()
    # Zielpfad: ZIP-Datei im venv-Ordner ablegen
    zip_path = os.path.join(root_dir, "venv", "project_files.zip")
    zip_non_binary_files(root_dir, zip_path)
    load_zip_to_clipboard(zip_path)

if __name__ == "__main__":
    main()
